<?php
$title = "CS:GO Fastbetz - Skin &amp; Item Betting - Virtual Lottery"; //TITLE название сайта
$sitename = "fastbetz.com"; //Сайт нейм для отображения в ник-нейме + некоторых частях сайта
$tradeurl = "https://steamcommunity.com/tradeoffer/new/?partner=312710162&token=l6cIm4wp"; // Trade Offer Link
?>